cursor1.wav
se03.wav
se04.wav
http://www.tam-music.com/se/se-menu.html